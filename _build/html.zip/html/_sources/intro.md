# Digital Skills for Materials 

Over the coming years you will develop a large number of skills as part of your training. Many of these skills are shared between the disciplines of materials science, physics, biology, chemistry and engineering. For example, it is expected to have developed skills in:

* digital skills including computer programming,

* statistical analysis,

* communication of results.

These skills are highly transferable and will likely be utilised in your future endeavours, regardless of whether you decide to pursue a career in industry or academia. Investing time in developing these skills at the start of your degree is the key to being successful and teaches you additional and highly asked after skills like:

* problem solving skills,

* creativity,

* logical and computational thinking,

* fundamental understanding how technology works,

* confidence to overcome any challenges.

Some parts of the course you find straight forward and others very challenging, which require a steep learning curve. However, we are here to lend you a hand.

## Module information

### Aims/Description:

The course is designed to teach students to interpret, analyse and present data using modern computational tools such as python. The students will learn how to use such packages for data analysis and then work through different data sets to determine how python can be used to perform the necessary mathematical functions on the this data and to clearly show trends and conclusions that can be drawn from the data.

Convenor: ?? 

Teaching Methods: Problem solving, Independent Study 

Credits: ??

Assessment: Formal Exam

The full module description can be found on  <a href="https://vle.shef.ac.uk/ultra/" target="_blank">Blackboard</a>.

Each week you will have a brief 10 min lecture, where we go through the core concepts and explain the principles. This will be followed with a computer lab session, where you can follow through a practical worksheet on <a href="https://colab.research.google.com/" target="_blank">Colab</a> and use the programming tools for yourself.

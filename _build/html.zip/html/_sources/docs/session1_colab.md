# Executing Jupyter Notebooks on Colab

Jupyter Notebooks are a community standard for communicating and performing interactive computing. It combines computational Tasks with explanatory text. Colab is a free cloud service by Google to create and share interactive notebooks with code, text, and visualizations.

:::{seealso}
<a href="https://jupyter.org/" target="_blank">Jupyter Project</a> and <a href="https://colab.google/" target="_blank">Colab</a>  for more details.
:::

A few examples to help you getting started with Colab and Jupyter Notebooks are given <a href="https://colab.research.google.com/#scrollTo=GJBs_flRovLc" target="_blank">here</a>.

To execute log into your <*your_username*>@sheffield.ac.uk google-account

![](../pictures/execute_colab.apng)

and click on the little rocket to open this notebook on Colab.

:::{Warning}
To save changes to and execute the notebook you need to make your own copy by selecting *File->Save a copy in Drive* from the menu bar in Colab.
:::
